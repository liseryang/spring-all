package com.cn.wuxiong.spring.solr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cn.wuxiong.spring.solr.service.DictionaryService;

@Controller
@RequestMapping(value = "/dictionary")
public class DictionaryCtrl {
	@Autowired
	private DictionaryService service;


	/**
	 * 主页
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String pagingList(Model model) {
		//model.addAttribute("TestAttribute", "欢迎进入");
		return "dictionary/dictionaryPage";
	}

	/**
	 * 添加一个景点
	 * 
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/addDictionaryItem", method = RequestMethod.GET)
	public synchronized String addDictionaryItem(Model model, HttpServletRequest request, HttpServletResponse response) {
		service.insertDictionaryItem();
		return "dictionary/dictionaryPage";
	}

}
