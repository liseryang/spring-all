package com.cn.wuxiong.spring.solr.dao;

import java.util.List;

import org.springframework.data.solr.repository.SolrCrudRepository;
import org.springframework.stereotype.Repository;

import com.cn.wuxiong.spring.solr.domain.DictionaryItem;

@Repository
public interface DictionaryDao extends SolrCrudRepository<DictionaryItem, Long> { // 这个接口中可以写一些StudentDao不能满足要求的方法。我这里纯粹测试好玩

	// The method name bellow will be translated into the following solr query
	// q=name:?0 AND popularity:?1
	List<DictionaryItem> findByName(String name);
}
