package com.cn.wuxiong.spring.solr.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.cn.wuxiong.spring.solr.dao.DictionaryDao;
import com.cn.wuxiong.spring.solr.domain.DictionaryItem;

public class DictionaryService {
	@Autowired
	DictionaryDao dao;
	
	public void insertDictionaryItem(){
		DictionaryItem di = new DictionaryItem();
		//di.setId(123L);
		di.setName("吴");
		di.setDetail("国家名称；姓氏；");
		di.setInsertDate(new Date());
		dao.save(di);
		
		System.out.println("保存后的id为："+ di.getId());
	}
}
