package com.cn.wuxiong.spring.solr.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.solr.core.SolrTemplate;

public class DictionaryDaoExImpl implements DictionaryDaoEx {
	@Autowired
	SolrTemplate solrTemplate;
}
