package com.cn.wuxiong.spring.solr.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface DictionaryDaoEx {

}
