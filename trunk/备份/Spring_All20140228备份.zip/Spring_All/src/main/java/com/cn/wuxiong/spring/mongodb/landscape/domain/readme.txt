这个landscape主要用来测试MongoDB的.

在MongoDB中是没有表这个说法的，只有文档(Document)，集合（Collection）这种说法。

集合（Collection）对于表（Table），文档对应每一条记录（Row）。
