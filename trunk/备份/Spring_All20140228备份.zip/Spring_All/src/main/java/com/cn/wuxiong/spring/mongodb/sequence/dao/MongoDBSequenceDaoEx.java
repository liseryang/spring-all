package com.cn.wuxiong.spring.mongodb.sequence.dao;


public interface MongoDBSequenceDaoEx {
	//public MongoDBSequence findByName();
}
