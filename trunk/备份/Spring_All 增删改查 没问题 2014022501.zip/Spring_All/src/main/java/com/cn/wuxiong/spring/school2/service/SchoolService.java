package com.cn.wuxiong.spring.school2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cn.wuxiong.spring.school2.dao.StudentDao;
import com.cn.wuxiong.spring.school2.domain.Student;

@Service
@Transactional
public class SchoolService {
	@Autowired
	private StudentDao dao_stu;

	public void testService() {
		System.out.println("###########################Test service");
	}

	public void addStudent(Student s) {
		dao_stu.persist(s);
		if (null != s.getId()) {
			System.out.println("##############" + s.getId());
		}
	}

	public void findAllStudcent() {
	}

	public void countStudents() {
	}

}
