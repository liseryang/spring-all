package com.cn.wuxiong.spring.school2.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cn.wuxiong.spring.school2.domain.Student;

@Repository
public class StudentDaoImpl implements StudentDao  {
	@PersistenceContext
	private EntityManager em;

	public void testFunc() {
		System.out.println("#############Test DAO");
	}

	public void persist(Student st) {
		em.persist(st);
		System.out.println("新创建的Student的ID:" + st.getId());
	}

	public int getStudentCount() {
		return 3;
	}
}
