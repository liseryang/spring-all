package com.cn.wuxiong.spring.school2.dao;

import org.springframework.stereotype.Repository;

import com.cn.wuxiong.spring.school2.domain.Student;

@Repository
public interface StudentDao {
	public int getStudentCount();

	public void persist(Student st);

	public void testFunc();

}
