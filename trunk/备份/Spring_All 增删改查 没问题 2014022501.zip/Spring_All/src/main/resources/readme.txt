这个项目里面可以实现了增删改查（通过entityManage实现），
但是，由于没有继承Spring的先关接口每个方法都需要手动实现。

而且 这里没有集成Spring Data MongoDB