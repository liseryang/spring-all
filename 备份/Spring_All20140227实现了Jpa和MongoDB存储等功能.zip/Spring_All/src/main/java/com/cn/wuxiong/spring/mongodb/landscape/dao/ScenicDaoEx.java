package com.cn.wuxiong.spring.mongodb.landscape.dao;

import com.cn.wuxiong.spring.mongodb.landscape.domain.ScenicSpots;

public interface ScenicDaoEx {
	public int getScenicSpotsCount();

	public void persist(ScenicSpots ss);

	public void testFunc();
}
