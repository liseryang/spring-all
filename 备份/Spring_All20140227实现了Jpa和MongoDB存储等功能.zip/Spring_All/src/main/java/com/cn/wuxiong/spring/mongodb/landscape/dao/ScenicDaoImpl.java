package com.cn.wuxiong.spring.mongodb.landscape.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cn.wuxiong.spring.mongodb.landscape.domain.ScenicSpots;

@Repository
public class ScenicDaoImpl implements ScenicDaoEx {//对于那些补充的方法的实现
	//@PersistenceContext
	//private EntityManager em;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	
	// @Override
	public void testFunc() {
		System.out.println("#############Test DAO");
	}

	public void persist(ScenicSpots ss) {
		System.out.println("进入保存……");
		mongoTemplate.insert(ss);
		System.out.println(ss);
	}
	public ScenicSpots findOneSS(Long id) {
		System.out.println("进入查找……");
		ScenicSpots ss  = mongoTemplate.findById(id, ScenicSpots.class);
		System.out.println(ss);
		return ss;
	}

	public Long findByCollectionName(){
		return 0L;
	}
	
	public int getScenicSpotsCount() {
		return mongoTemplate.findAll(ScenicSpots.class).size();
	}
	
	
}
