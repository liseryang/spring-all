这个landscape主要用来测试MongoDB的.

在MongoDB中是没有表这个说法的，只有文档，集合这种说法。

集合对于表，文档对应每一条记录。
