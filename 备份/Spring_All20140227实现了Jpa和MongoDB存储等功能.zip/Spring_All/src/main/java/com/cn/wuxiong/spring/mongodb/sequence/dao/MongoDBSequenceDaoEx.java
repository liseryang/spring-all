package com.cn.wuxiong.spring.mongodb.sequence.dao;

import com.cn.wuxiong.spring.mongodb.sequence.domain.MongoDBSequence;

public interface MongoDBSequenceDaoEx {
	//public MongoDBSequence findByName();
}
