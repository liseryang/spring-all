package com.cn.wuxiong.spring.mongodb.landscape.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class ScenicSpots {
	@Id
	private Long id;
	private String name;
	private Double ticketPrice;
	private Integer openTime;
	private Integer closeTime;
	private String remark;

	public ScenicSpots() {
	}

	@PersistenceConstructor
	ScenicSpots(String name, String remark) {
		super();
		this.name = name;
		this.remark = remark;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public int getOpenTime() {
		return openTime;
	}

	public void setOpenTime(int openTime) {
		this.openTime = openTime;
	}

	public int getCloseTime() {
		return closeTime;
	}

	public void setCloseTime(int closeTime) {
		this.closeTime = closeTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "ScenicSpots [id=" + id + ", name=" + name + ", ticketPrice="
				+ ticketPrice + ", openTime=" + openTime + ", closeTime="
				+ closeTime + ", remark=" + remark + "]";
	}
}
