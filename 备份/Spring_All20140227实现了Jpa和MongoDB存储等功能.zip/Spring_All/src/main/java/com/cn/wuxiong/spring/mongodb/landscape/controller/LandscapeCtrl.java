package com.cn.wuxiong.spring.mongodb.landscape.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cn.wuxiong.spring.mongodb.landscape.domain.ScenicSpots;
import com.cn.wuxiong.spring.mongodb.landscape.service.ScenicService;
import com.cn.wuxiong.spring.mongodb.sequence.service.MongoDBSequenceService;

@Controller
@RequestMapping(value = "/landscape")
public class LandscapeCtrl {
	@Autowired
	private ScenicService service;

	@Autowired
	private MongoDBSequenceService mss;

	/**
	 * 主页
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String pagingList(Model model) {
		model.addAttribute("TestAttribute", "欢迎进入");
		return "landscape/landscapePage";
	}

	/**
	 * 添加一个景点
	 * 
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/addAscenic", method = RequestMethod.GET)
	public synchronized String addAAscenic(Model model,
			HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("TestAttribute", "what a nice view?");

		service.findCount();

		ScenicSpots ss = new ScenicSpots();
		Long id = mss.addOrIncSequence(ScenicSpots.class.getSimpleName());
		ss.setId(id);
		ss.setName("飞沙洲");
		ss.setOpenTime(8);
		ss.setCloseTime(18);
		ss.setTicketPrice(50.0);
		ss.setRemark("落霞与孤鹜齐飞，秋水共长天一色。");
		service.addScenic(ss);
		return "landscape/landscapePage";
	}

	/**
	 * 查找一个景点
	 * 
	 * @return
	 */
	@RequestMapping(value = "/findAscenic", method = RequestMethod.GET)
	public String findAAscenic() {
		ScenicSpots ss = service.findScenic(123L);
		System.out.println(ss);
		return "landscape/landscapePage";
	}

	/**
	 * 删除一个景点
	 * 
	 * @return
	 */
	@RequestMapping(value = "/deleteAscenic", method = RequestMethod.GET)
	public String deleteAAscenic() {
		service.deleteScenicById(123L);
		return "landscape/landscapePage";
	}

	/**
	 * 更新一个景点
	 * 
	 * @return
	 */
	@RequestMapping(value = "/updateAscenic", method = RequestMethod.GET)
	public String updateAAscenic() {
		service.updateScenic(123L);
		return "landscape/landscapePage";
	}

}
